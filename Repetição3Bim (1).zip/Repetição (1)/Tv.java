import java.util.Scanner;

public class Tv {
    final static Scanner LER = new Scanner(System.in);

    public static void main(String[] args) {
        int v = 0; // volume inicial
        int t = 0; // numero de troca de volume
        int ai = 0; // modificacoes do volum realizada

        v = lerV(v);
        t = lerT(t);

        for (int i = 0; i < t; i++) {
            
            ai = lerAi(ai);
            v = verificarVolume(v, t, ai);
        }
       
        imprimirVolume(v);
    }

    public static int lerT(int t) {
        do {
            t = LER.nextInt();
        } while (t < 0 || t > 1000);
        return t;
    }

    public static int lerV(int v) {
        do {
            v = LER.nextInt();
        } while (v < 0 || v > 100);
        return v;
    }

    public static int lerAi(int ai) {
        do {
            ai = LER.nextInt();
        } while (ai < -100 || ai > 100);
        return ai;
    }

    public static int verificarVolume(int v, int t, int ai) {
        v += ai;
        if (v >= 100) {
            v = 100;
            return v;
        } else if (v <= 0) {
            v = 0;
            return v;
        } 
        return v;
        
            
        }
  
    public static void imprimirVolume(int v) {
        System.out.println(v);
    }
}