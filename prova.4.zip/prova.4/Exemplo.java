import java.util.Scanner;

public class Exemplo {
    final static Scanner LER = new  Scanner(System.in);
    public static void main(String[] args) {
        
        String texto = " ";
        texto = lerTexto(texto);

        texto = removerEspacos(texto);
        texto = converterParaMaiusculas(texto);
        tabelascii();

        int[] contagemLetras = contarLetras(texto);

        exibirContagemLetras(contagemLetras);
    }

    public static void tabelascii() {

    }

    public static String lerTexto(String texto) {
        texto = LER.nextLine();
        return texto;
    }

    public static String removerEspacos(String texto) {
        return texto.replaceAll("[\t\n]", "");
    }

    public static String converterParaMaiusculas(String texto) {
        return texto.toUpperCase();
    }

    public static int[] contarLetras(String texto) {
        
        int[] contagemLetras = new int[10000];

        for (int i = 0; i < texto.length(); i++) {
            char caractere = texto.charAt(i);
            if (Character.isLetter(caractere)) {
                contagemLetras[caractere - 'A']++;
            }
        }

        return contagemLetras;
    }

    public static void exibirContagemLetras(int[] contagemLetras) {
        for (char letra = 'A'; letra <= 'Z'; letra++) {
            int aux = letra - 'A'; 
            if (contagemLetras[aux] > 0) {
                System.out.println(letra + ": " + contagemLetras[aux]);
            }
        }
        for (char letra = 'ü'; letra <= 'Ü' ; letra++) {
            int aux = letra - 'ü'; 
            if (contagemLetras[aux] > 0) {
                System.out.println(letra + ": " + contagemLetras[aux]);
            }
        }
    }
}
