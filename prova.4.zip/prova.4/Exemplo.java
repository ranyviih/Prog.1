import java.util.Scanner;

public class Exemplo {
    final static Scanner LER = new  Scanner(System.in);
    public static void main(String[] args) {
        
        String texto = " ";
        texto = lerTexto(texto);

        texto = removerEspacos(texto);
        texto = converterParaMaiusculas(texto);
        tabelascii();

        int[] contagemLetras = contarLetras(texto);

        exibirContagemLetras(contagemLetras);
    }

    public static void tabelascii() {

    }

    public static char lerTexto() {
        char[] texto = LER.next().toCharArray();
        return texto;
    }

    public static String removerEspacos(String texto) {
        return texto.replaceAll("\\s", "");
    }

    public static String converterParaMaiusculas(String texto) {
        return texto.toUpperCase();
    }

    public static int[] contarLetras(String texto) {
        Character ch = texto.charAt(0);

        System.out.println(Character.isLetter(ch));
        int[] contagemLetras = new int[26];

        for (int i = 0; i < texto.length(); i++) {
            char caractere = texto.charAt(i);
            if (caractere >= 'A' && caractere <= 'Z') {
                contagemLetras[caractere - 'A']++;
            }
        }

        return contagemLetras;
    }

    public static void exibirContagemLetras(int[] contagemLetras) {
        for (char letra = 'A'; letra <= 'Z'; letra++) {
            int indice = letra - 'A';
            if (contagemLetras[indice] > 0) {
                System.out.println(letra + ": " + contagemLetras[indice]);
            }
        }
    }
}
