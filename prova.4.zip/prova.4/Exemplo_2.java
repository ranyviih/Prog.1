import java.util.Scanner;

public class Exemplo_2 {
    final static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args) {
        String nome = "Thiago Berticelli Ló";
        String procura = "Ló";

        int pos = nome.indexOf("i"); //pega o primeiro que aparecer;
        // System.out.println(pos);

        int posi = nome.indexOf("", 3); // eu quero o primeiro i apartir de tau posição
        // System.out.println(posi);

        int posic = nome.toUpperCase().indexOf(procura.toUpperCase()); //transforma para maiuscula e a entrada tbm aceitando qualquer tipo de escrita
        //System.out.println(posic);

        nome = nome.replace("ó", "o");
        nome = nome.replace("ã", "a");
        //System.out.println(posic);

        //imprimrPosicoesDaBuscaString(nome);
        char c;
        //int r = contagemDeFrequencia(nome, c);

        // char[] arrayNome = nome.toCharArray();
        // System.out.println(arrayNome);

        // teste();

        // de uma posicao ate outra posicao
        int posI = 2;
        int pos2I = 14;
        //System.out.println(nome.substring(posI, pos2I));  

    }
    public static int contagemDeFrequencia(String nome, char r) {
        int cont = 0;
        String entrada = "";
        char[] vetor;
        vetor = entrada.toCharArray();

        for (int i = 0; i < vetor.length; i++) {
            if (r == vetor[i]) {
                cont++;
            }
        }
        return cont;
    }
    public static void imprimrPosicoesDaBuscaString( String nome) {
        int posi = 0;
        int aux = 0;
        
       do {
            posi = nome.indexOf("i", posi );
            System.out.println(posi);

            if (posi == -1)
            break;

            posi++;
            
        } while (posi != -1);
    }
}