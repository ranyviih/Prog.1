import java.util.Scanner;

public class Bataha {
    final static Scanner LER = new  Scanner(System.in);
    public static void main(String[] args) {
       
        
    }
    
}