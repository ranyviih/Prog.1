public class ContagemCaracter {
    public static void main(String[] args) {
        String texto = "Aqui você colocaria o seu texto de 10000 palavras..."; // Aqui você colocaria o texto desejado

        texto = removerEspacos(texto);
        texto = converterParaMaiusculas(texto);

        int[] contagemLetras = contarLetras(texto);

        exibirContagemLetras(contagemLetras);
    }

    public static String removerEspacos(String texto) {
        return texto.replaceAll("\\s", "");
    }

    public static String converterParaMaiusculas(String texto) {
        return texto.toUpperCase();
    }

    public static int[] contarLetras(String texto) {
        int[] contagemLetras = new int[26];

        for (int i = 0; i < texto.length(); i++) {
            char caractere = texto.charAt(i);
            if (caractere >= 'A' && caractere <= 'Z') {
                contagemLetras[caractere - 'A']++;
            }
        }

        return contagemLetras;
    }

    public static void exibirContagemLetras(int[] contagemLetras) {
        for (char letra = 'A'; letra <= 'Z'; letra++) {
            int indice = letra - 'A';
            if (contagemLetras[indice] > 0) {
                System.out.println(letra + ": " + contagemLetras[indice]);
            }
        }
    }
}
